- Unzip rev627_linux an compile
	- We have not run the SWAT model in linux, but in Windows the executable file has to be in .../Default/TxtInOut folder.
	  Based on this, I imagine the make has to occur within this folder.
	  
- run SWAT model located in ../Default/TxtInOut folder
- If run successfully, you should be able to see an output similar to the "Test_cmd_output.jpg" screenshot.
